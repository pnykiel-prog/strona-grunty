# Social Living Europe — wytyczne: strona reklamowa (landing)

Wytyczne do zbudowania publicznej strony reklamującej bezpłatną analizę działek pod dofinansowane
budownictwo społeczne. Referencja 1:1: **`Landing Analiza Dzialek.dc.html`** — otwórz i „podglądaj
kodem”, wszystkie wartości są inline. Zrzuty sekcja po sekcji: `zrzuty/01–09-landing.png`.

> Zasada nadrzędna: **wiarygodność ponad efekt.** Strona obiecuje „nawet do 100% finansowania” —
> krzykliwy design przy takim haśle wygląda na scam. Ton: poważna instytucja finansowa + nowoczesny
> fintech. Liczby są bohaterami, oprawa powściągliwa, gwiazdki nigdy nie ukryte.

---

## 1. Marka i paleta

Brand: **Social Living Europe**. Logo: `logo-sle.png` (sygnet: dwie bryły — złota i zielona — z figurami
ludzi). W nagłówku: sygnet 40×40 (`object-fit:contain; object-position:top`) + wordmark: „Social Living”
**Playfair Display 600 / 19px** + „EUROPE” 9.5px, `letter-spacing:.28em`, uppercase, złoto.

| Rola | Hex |
|---|---|
| Zieleń brandowa (tekst, chrome, CTA) | `#12312A` |
| Zieleń CTA / akcent | `#0F4A38` |
| Zieleń ciemna sekcji | `#0C2A21` · `#071B15` (najciemniejsza) |
| Zieleń gradientu | `#174535` · `#1B5240` |
| **Złoto (akcent)** | `#C89B4A` (jaśniejszy w tekście: `#E3C089`) |
| Tło jasne / tint sekcji | `#fff` · `#EDF2EF` · `#F4F8F6` |
| Obrys karty | `#DFE6E2` · separatory `#DCE6E1` |
| Tekst pomocniczy | `#3A4D6B` · `#5C6B82` · `#6B7A92` · `#8E9BAE` |
| Ostrzeżenie (bursztyn) | `#B5790B` / tło `#FBF7EC` |

Typografia: **IBM Plex Sans** (UI, nagłówki), **IBM Plex Mono** (liczby, ID, źródła, `tabular-nums`),
**Playfair Display** wyłącznie do wordmarku.

## 2. Rytm sekcji (kolejność + tło)

Sekcje **przylegają do siebie** — nie dawaj `margin-top` sekcji, która ma własne tło (powstaje biały
pasek). Naprzemienne tła budują kontrast:

| # | Sekcja | Tło |
|---|---|---|
| — | Nav (sticky, `rgba(255,255,255,.88)` + blur) | biały półprzezroczysty |
| 1 | **Hero** | ciemna zieleń + szkic budynku + maski |
| 2 | Hak / problem | `#fff` |
| 3 | Jak to działa (3 kroki) | `#EDF2EF` |
| 4 | Finansowanie (3 kafle) + **blok wkładu własnego** | `#fff` |
| 4b | **Rola gminy** | `#F4F8F6` |
| 5+6 | Skala PL (6 kafli, 3+3) i EU (5 kafli) | `#0C2A21` + gradient |
| 7 | Dla kogo (2×2) | `#fff` |
| 8 | Dlaczego my (4 punkty) | `#EDF2EF` |
| 9 | FAQ (accordion) | `#fff` |
| 10 | Finalne CTA | ciemna zieleń, `radius 20` |
| 11 | Źródła (accordion) | `#fff` |
| 12 | Stopka + zastrzeżenia | `#071B15` |

Szerokość treści **1180px**, padding boków 28px, padding pionowy sekcji 66–74px.

## 3. Komponenty

- **CTA (jeden dominujący, powtarzany 8×):** „Sprawdź działkę za darmo”, `background:#0F4A38`, biały
  tekst 15–16.5px/600, `height 50–56`, `radius 11–12`, `box-shadow:0 6px 20px rgba(15,74,56,.35)`.
  Wariant drugorzędny: outline `1px solid rgba(255,255,255,.28)` (na ciemnym) lub `#C7D0DC` (na jasnym).
  **Nie mnóż stylów przycisków.**
- **Formularz startowy (hero, prawa kolumna):** biała karta `radius 16`, cień `0 26px 64px rgba(4,12,24,.45)`;
  tytuł „Bezpłatna analiza działki” 17px/600, podpis 13px; jedno pole (mono 15px, `height 52`) + CTA pełnej
  szerokości + nota o danych publicznych. Próg wejścia = 1 pole.
- **Karta (uniwersalna):** `background:#fff`, `border:1px solid #DFE6E2`, `radius 12–14`, `padding 24`,
  **cień `0 6px 20px rgba(12,49,42,.10), 0 1px 2px rgba(12,49,42,.06)`** — kafelki muszą być wyraźnie
  odklejone od tła.
- **Kafel liczbowy (stat card) — JEDEN wygląd dla PL i EU:** na ciemnym tle
  `background:rgba(255,255,255,.06)`, `border:1px solid rgba(255,255,255,.14)`, blur; liczba 28px/600
  biała `tabular-nums`, podpis 13px `#CFE0D8`, **mikro-źródło** 11px mono nad linią `rgba(255,255,255,.10)`.
- **Blok „wkład własny” (kluczowy komunikat):** ciemny gradient `linear-gradient(135deg,#0F4A38,#0C3A2C)`,
  `radius 16`, cień `0 16px 40px rgba(12,49,42,.30)`; złoty kwadrat 44px ze znakiem „+”, nadtytuł złoty
  10.5px uppercase `ls .14em`, hasło **27px/600 białe** ze złotym wyróżnieniem, opis 15.5px `#CFE0D8`,
  nota warunkowa 12.5px nad linią + link do stopki.
- **Karta grupy docelowej:** ikona-kafelek 42px + tytuł 18px + zdanie + link-CTA. Karta **„Gminy — także
  mniejsze” wyróżniona**: obrys `1.5px #0F4A38`, tło `#F7FBF9`, pigułka „NASZA PRZEWAGA”.
- **Accordion (FAQ, źródła):** wiersz-przycisk, pytanie 16px/600, znak `+`/`−` w kółku 28px
  (otwarty: tło `#12312A`, biały znak). Odpowiedź 14.5px, `line-height 1.6`.

## 4. Hierarchia zaufania (sedno)

- Przy każdym mocnym twierdzeniu („do 100%”, „do 35/80%”, „zapewniamy wkład własny”) **widoczna gwiazdka**
  linkująca do `#zastrzezenia` lub `#stopka-zastrzezenia`. Nigdy nie chowaj.
- Każda liczba w sekcji Skala ma **mikro-źródło** (instytucja / rok); rozwijana sekcja **Źródła**
  wymienia instytucja + rok + domena.
- Stopka zawiera **pełne zastrzeżenia prawne** (5 punktów): narzędzie wstępnej analizy (nie doradztwo,
  nie oferta) · maksymalne warunkowe poziomy + limit dopuszczalnej rekompensaty · finansujemy wybrane
  projekty · wkład własny dla wybranych po kwalifikacji · wyłącznie budownictwo społeczne i komunalne,
  wymaga współpracy z samorządem.

## 5. Przekaz — nacisk merytoryczny

1. **Wyłącznie budownictwo społeczne i komunalne** (najem o umiarkowanym czynszu) — powtórzone w hero,
   haku, finansowaniu, FAQ i stopce. Nie mieszkania na sprzedaż.
2. **Wkład własny dla wybranych projektów** — osobny, mocno wyróżniony blok (patrz §3).
3. **Współpraca z samorządem jest warunkiem koniecznym** — osobna sekcja „Rola gminy”: umowa z gminą
   otwiera grant · forma współpracy determinuje pułap (35% vs 80%) · przygotowujemy materiał dla gminy ·
   **prowadzimy rozmowy z samorządem**. Plus akcent: także mniejsze gminy.
4. Skala programów: 8,7 mld zł · 4,02 mld zł · ~18 tys. mieszkań · ~900 lokalizacji · **do 10 mld zł
   rocznie do 2030 (deklaracja rządowa)** · do 4 mln rodzin. EU: EBI 6 mld €, EBI+BGK, Plan UE,
   InvestEU 372 mld €, EBOR.
5. Kredyt preferencyjny: **30 lat · 1–2%**, spłacany z czynszu.

## 6. Responsywność (mobile-first)

- Wszystkie siatki: `grid-template-columns: repeat(auto-fit, minmax(X,1fr))` — nigdy `repeat(N,1fr)`
  (przy sztywnych `fr` kolumna formularza w hero zwija się do 0px).
  Wartości X: hero `330px` · kafle 3-up `250px` · Dla kogo `420px` (wymusza 2×2) · Dlaczego my `220px` ·
  stat PL `300px` (3+3) · stat EU `185px`.
- Nav: `flex-wrap:wrap`, etykiety `white-space:nowrap`.
- **Sticky CTA na mobile:** `#stickyCta` `position:fixed; bottom:0`, widoczny tylko `@media (max-width:720px)`
  (wtedy `#navCta` ukryty, `body{padding-bottom:78px}`). To jedyne dozwolone `@media` — w bloku `<style>`.

## 7. Czego UNIKAĆ

- Sygnałów scamu: liczników odliczających, „tylko dziś”, ukrytych gwiazdek, „100% ZA DARMO” bez kontekstu.
- Więcej niż jednej głównej myśli na sekcję; konkurujących CTA (jeden dominujący przycisk).
- Jaskrawych gradientów, neonów, czerwieni, emoji dekoracyjnych.
- `margin-top` na sekcji z własnym tłem (biały pasek) i dwóch sąsiadujących sekcji w tym samym kolorze.
- Sztywnych `repeat(N,1fr)` w siatkach.

## 8. Checklista przed „gotowe”

- [ ] Jeden styl CTA, powtórzony w hero, po każdej sekcji, w CTA końcowym i stopce.
- [ ] Formularz „wpisz działkę” widoczny od razu, także na mobile; nie zwija się do 0px.
- [ ] Gwiazdki przy „do 100%” / „wkład własny” linkują do widocznych zastrzeżeń.
- [ ] Kafle liczbowe PL i EU identyczne wizualnie, każdy z mikro-źródłem; siatki symetryczne (3+3, 2×2).
- [ ] Kafelki mają wyraźny cień; sąsiadujące sekcje różnią się tłem, bez pustych pasków.
- [ ] Blok „wkład własny” wyróżniony ciemnym gradientem ze złotym akcentem.
- [ ] Sekcja „Rola gminy” obecna, z komunikatem, że prowadzimy rozmowy z samorządem.
- [ ] Pełne zastrzeżenia prawne w stopce; sticky CTA na mobile.
- [ ] Zgodność 1:1 z `Landing Analiza Dzialek.dc.html` i zrzutami.
